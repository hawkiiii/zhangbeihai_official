#  《野狼Disco》就是中国后现代说唱艺术之光

原创  章北海  章北海  章北海的自然选择

_2019年10月28日 08:15_ __ _ _ _ _

在小说阅读器读本章

去阅读

  

YES！

DISCO！

**为什么**

**野** **狼** **D** **I** **S** **C** **O**

**是中国后现代说唱艺术之光**

///

**🎵** **跟我摇就完事了**

  

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNGBAuJ63yIdRg5B1LkgqUicYHngmdSPrMlLPsTQr5Om4cHp3OmGcw1dQ/640?wx_fmt=jpeg)

灯红酒绿

这曾经是东北迪厅

也是东北再也回不去的

好日子

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNtgsL4wO4p7450fnkClRj1IlfmpgdrskH2kEbrDuFFlRlPpJvhxd1icA/640?wx_fmt=jpeg)

  

  

**零**

**【红极一时 】**

  

**语音才是灵魂**  

**👇**

在这个年代能红的歌一般走两个极端，要么特别好，要么特别烂。

  

《学猫叫》这种口水歌就是属于特别烂，根本不知道音乐作品的出发点在哪，属于无根之水。

  

特别好的作品也很多， **崔健的歌之所以能火** ，能在上个世纪七八十年代，中国受众那么挑剔的音乐口味之下红起来，
**不是没有道理的，他唱的是一个时代的年轻人的精神。**

  

**所以陈鸿宇今天走的也是这个路子，只不过年轻人们的时代精神变了，从那种反抗的摇滚范儿变成了低回婉转的民谣风格。**

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQN1Xpbky12TYGx3eBTPqV6FTV0E7yN1FoQj9rKDoNfxzEaIfIHKg2dgA/640?wx_fmt=jpeg)

崔健当年的《一块红布》

太够范了 太叛逆了

那个年代的年轻人就是这样子

  

**《野狼DISCO》不属于这两种类型当中的任何一种，它属于烂的特别好** ，好的出奇，好到能让人想起来，过去东北年轻时代的好日子。

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNJnEMciazhlib6mq386gm8teEqZVichfqMNV3OYO7d18icphGXu19BG7e3Q/640?wx_fmt=jpeg)

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNpmp5QMlsNLW20Sqx6utbA5WPnkzdvPajrXSh5We3trjxGhibdWibuPibA/640?wx_fmt=jpeg)

看看这土味封面

暴雪的美工也救不了

真正的土味审美

也是真正的大众文化

  

**壹**

**【先富后富】**

  

  

在总工程师同志提出让一部分人先富起来之前，东北就已经先富起来了，深圳还是个渔港，只有两条巷子的时候，
**东北这个曾经的共和国长子就已经大跨步的迈入了现代化，城市化和工业化。**

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNnjvq6VaVtLHsLgIhENWr41tjTj9sXC45q5IAao9eAicArTWUmPUfefg/640?wx_fmt=jpeg)

哈尔滨七八十年代图景

已经步入现代城市生活

  

一方面是由于东北本身就物产丰富，而另一方面是由于日本侵略者对东北的开发掠夺所留下来的工业遗留。

  

**所以新中国成立之初这里就是全中国最重要的重工业基地，祖国建设需要的钢铁和石油从这里运输到全国每一个角落。**

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNfxeIq1ojzHvnjm7BlZ0beZfYX3ibU63xaBs25wicGu0RCH24CBXj3DDA/640?wx_fmt=jpeg)

大庆油田上缴了4061亿元税金  

是对大庆总投资的87倍

记住，这是几十年前的4000亿

极大支援了全国的建设

  

举个例子，雷锋同志是湖南长沙人，但是他开拖拉机却是在东北的鞍山钢铁厂，王进喜是甘肃人，却在黑龙江的大庆油田贡献了自己的一生，可以说新中国前30年的建设离不开谈重工业，谈重工业就离不开谈东北。

  

**正是这30年的建设，让很多全国各地的人移民到东北，成为了新东北人，而再往前，东北的人口大多数是清朝末年出关讨生活的北方群众，换句话说东北就是中国的美国，是中国最大的移民中心。**

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNYCfnZMGtIhMCe1QkouG4jAVLyFgicph4iaSpibp1ffLDDHRpL7IwfYWHw/640?wx_fmt=jpeg)

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNhPMQgLFEgsW9wDwzR3UlNMKNib9ibIOxwOQKT1MmUrTNevpdbU37akKw/640?wx_fmt=jpeg)

雷锋和王进喜

是新东北移民的代表

中国改革开放的经验证明了城市化的第一步是工业化，东北地区早在新中国改革开放之前就已经完成了初步的工业化，今天东北地区有不到1.1亿人口，如果算上热河地区会更多。

  

相当于内地两个中等人口省或者略多于一个大省的人口总量，然而却拥有43个地级市，4个全国性城市，沈阳 大连 哈尔滨和长春。

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNUAbqDJ7BO6TfVV1OKT1DHR62kI5WWwfiaHkkm7GuicOXazrqMVa40L0A/640?wx_fmt=jpeg)

航母为什么叫辽宁号

因为共和国不可能忘记辽宁

  

根据历史统计数据，如果以城市化率来衡量省份的发展水平.

**  
**

**辽宁在1996年就有44%的城市化率，对比较发达省份，领先广东4年，福建6年，海南8年，如果以较落后省份来计算领先宁夏17年，贵州和甘肃20年。**

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNu0pWjHSibcgbicPS8XkKEO4zoyxicUE1VFsCYuYrMpFLjgPZUk9N0be7Q/640?wx_fmt=jpeg)

中国城市化率图表

东北的城市化决定了生活方式

  

在新世纪之前，改革开放一方面给东北带来了大量外部世界的新鲜玩意儿，也没有发展迅速到让东北由盛转衰。这为今天衰落中的东北提供了一段可怀念的历史。

****

**《野狼disco》的背景就在这个年代的东北。**

  

  

  

**贰**

**【文化隐喻】**

  

  

《野狼disco》土吗？用新世纪的眼光来看，当然土， **但是在上个世纪八九十年代的东北，这就是最先进的文化潮流的方向。**

  

丝毫不亚于今天一线城市的年轻人们在酒吧里面喝威士忌，听外语歌曲蹦迪。

  

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNE4CakYsWsFnTn3lED3yWvWGC8RicEXhTXkKl3TuEJhhy1NpuWvOCNlQ/640?wx_fmt=jpeg)

90年代的迪厅

和今天对比

没啥大区别

没啥大变化

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNgOPDMahxwXaXTDjHYNzIkNQpGrf31shwatgxpwACT8KbhXLLLYVHxg/640?wx_fmt=jpeg)

当然那个年代不兴听外语歌曲，而是流行听粤语歌。相较于一个字也听不懂的英语，同为是汉语的粤语至少保留了一定熟悉成分，但作为一种和北方方言差距较大的方言系统，又有着足够的陌生性来创造审美距离，
**在艺术上说，这叫满足了当时东北社会的期待视野。**

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNuQ3Aj5ZrdupBFMmUlLtuqRhfq9PzFUdtLlHD2fJoqfnKvhxH0tAPhA/640?wx_fmt=jpeg)

梵高的画不被人赏识

因为当时的审美局限

他超越审美期待视野太多了

直到今天人们才能看到它的美

  

贾樟柯的电影《山河故人》，入围了2015年的戛纳金棕榈奖，获得了第52届金马奖。故事的一条暗线是1990年叶倩文的一首粤语歌《珍重》,文化背景是2000年前后的山西，这从一个侧面体现出了东北对于全国文化欣赏的领先。

  

**东北地区对粤语歌曲的欣赏要追溯到上世纪80年代，因为只有较为接近的经济水平和城市化水平，才能够孕育足够产生对话与共鸣的文化基础，用马克思的观点说，这叫经济基础决定上层建筑，上层建筑反应经济基础。**

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQN6icqoo2icOFnq8jibKtIBib48LYDicLwJKbM9J6XQAOAfR0bWeIr36t3kPw/640?wx_fmt=jpeg)

上世纪八九十年代的迪厅

留到今天的真的不多了

  

所以这首歌当中不标准的粤语歌词实际上是一种对上世纪东北黄金时代的一种怀旧，事实上这种文化意象所构成的隐喻并不少见，比如东北男女平等所带来的文化解放思潮，造成的迪厅里面有着大量烫着头蹦着迪的年轻姑娘，欠发达地区的姑娘想蹦迪，差不多要等10年以后，还会被视为不三不四的盲流。

  

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNr8g41roJnhx9ibBiar14YKoBoQkOGhAXPrygA9v1yx5ibo98r23NJojtA/640?wx_fmt=jpeg)

真正的女权.JPG

/

虚假的女权.JPG

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNkyqwfLhjLpOVm2g8sROq82XicTSpk2yQxckupFfA0Doe9cYpoZB8frw/640?wx_fmt=jpeg)

  

大背头
007以及大哥大众多上世纪的流行玩意儿构成了这首歌的主体，能够在张嘴的第一瞬间把你拉回到90年代的东北，身边就是蹦迪的大哥一边灌啤酒一边告诉你蹦就完事了。

****

**这就是东北人永远也回不去的好日子，有的人听的是歌，有的人听的是歌里的时代。**

  

  

  

**叁**

**【伤痕文学】**

  

《野狼disco》是不折不扣的伤痕文学，但他高就高在，一点伤痕也没有让你看见。

  

**振兴东北喊了差不十年了，然而东北依旧是老样子，Gdp注水，经济低迷，连兜底的养老保险都开始见底，人情社会所带来的社会运行阻力，让投资不过山海关的言论甚嚣尘上。东北从共和国的长子变成大家不想去，甚至要争相离开的地方，每年净流出的都是年轻人口，只有老人愿意留在这片土地上。**

  

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNgKr1EqqXMjCVN2O9iceic6enOE5M9a0JC6MjiakS6WF67bUicBunIWiajiaA/640?wx_fmt=jpeg)

老龄化和流失人口

造成实际劳动力萎缩

东北经济不跌就不错

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNwH2P7czb5NKMSBdTfWuXltn9EbODQCibBUtlhuOLH9Nrz3y3DtGQJFw/640?wx_fmt=jpeg)

**这和新中国前30年的历史形成了截然对比，40年前这些人来到东北这片土地，40年后他们的子女依旧寻找他们该去的地方，完成了历史的一种循环。**

****

说句难听的话，东北就是美国的底特律铁锈带，是法国的阿尔萨斯和洛林，是德国的鲁尔区，是后工业时代的衰退废土

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNQTD3IJZYteoiaEoMudiagX26iaaYYmE916IibAHW2mYaZNACsIUYOmJHNw/640?wx_fmt=jpeg)

美国铁锈带的工厂

如果我说这是东北

毫无违和感

  

但这也正是这首歌的超越所在，它并不直接把东北的衰退，东北工人的不甘，老工业中心的退场等等种种伤痕已表现出来，他只通过一个小迪厅里面的DJ表现出来，让这个小角色活生生地告诉你，这里曾经是一副什么样土里土气又热闹繁华的景象。

****

**怀念完事还得问你一句，别看兄弟现在不行了，兄弟以前牛逼不？**

****

**你这时候只能发自内心地说，兄弟牛逼**

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNciavf6fNJtEVibOvKCVq4RDibuibD9iaGh2icmLiagBrQVryIibFKMZD8UwW7g/640?wx_fmt=jpeg)

东北人还有一样秘密武器

那就是地理造就的乐观

这也造就了东北的喜剧天赋

  

**肆**

**【现代艺术】**

  

  

说起来你们可能不信，《野狼Disco》实际上和毕加索还有梵高等等西方现代派艺术有异曲同工之妙。

  

**从纯音乐的角度上来说，这首歌的乐理组成和钢琴音色的和弦都很有年代感，节奏类型相比这个年代的电脑制作歌曲有点过于简单，这并非是在音乐上的不成熟，而是刻意而为之，造成了一种怀旧的氛围。**

  

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQN9VX7vCeicux7OmRWMzaIic4Vc9Xmfss7CoWQzR0nbMYbXz5s4XX5MJvA/640?wx_fmt=jpeg)

实际上野狼DISCO

和蒸汽波内核很接近

都是对浮华年代的解构

以及再创造

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNqibz1vAlICZqn7I5mOTUT2wsf6JPrDiaMmf0icOw4rUFRxUhOic7Kh0Wkg/640?wx_fmt=jpeg)

  

这种境界的差距有点类似于聪明人扮傻子和傻子扮聪明人，聪明人可以装的很傻，但傻子永远不可能装的很聪明。

  

**我们再去看看毕加索，看看梵高，抽象的线条，疯狂的色彩，这和古典主义的艺术完全划清了界限，没有欣赏能力的人对着这些艺术作品会说这是丑陋的，但当你了解了这些作品的思想精神和所抒发的人的内心情感，你会发现这些作品是站在古典艺术的基础上又更前进了一步。**

  

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNSfFHibuWN0V1GPuuicaRHVHXibNy5EFexUpmyLwJzo96iaOM1VUMwmictlQ/640?wx_fmt=jpeg)

毕加索十一岁的素描

和对牛简化的推演

立体主义是在古典基础上诞生的新画法

只看到凌乱的线条

就会陷入无知的自大

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNqz5ndWiaHjVMvZvt8USHhxD11RjOrLD2MDd7ic6j4hrEGznmreXpaW9Q/640?wx_fmt=jpeg)

《毛诗序》说，言之不足，故歌咏之。歌唱本来就是强烈抒情的一种方式，这种可以不注重当下的现实的生活，而对强烈的抒情和个人内心的色彩大加笔墨，这是和现代主义的艺术相呼应相吻合的。

  

巴比松画派的米勒，世界级的油画大师，1850年有人批评他说，在他的画作的农民里面看见了六月革命时候巴黎人民的形象,

  

**他画作的那种粗劣的五官，朴拙的线条和丰富的光影，和野狼disco当中贫瘠的编曲，和粗俗的台词和是同质异构，不同的形式所表达的都是一个同样的精神内核。**

  

**大俗大雅，大雅大俗，不外乎此理**

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNCFaibRnnFWPMgZGwNLc3mJDiaib6Zsqua7gAZmdibvhsiaWhf4r2W6qWiaiaA/640?wx_fmt=jpeg)

米勒《播种者》

透过粗粝的画风和线条

有人从地平线上看见了革命者

  

而这首歌的结构上也有一个现代美学的彩蛋，它使用的是循环套层的结构，开始就是结束，结束就是开始。在你单曲循环这首歌的时候，结束的念白接上开场的念白，构成了完整逻辑。

  

整首歌结束的时候他接到朋友求救的电话，而这首歌开始的时候，是他第二次挂断朋友的电话，从而刻画了一个贪生怕死又酷爱耍酷蹦迪的东北小市民形象。

  

**这首歌的精髓，你如果不单曲循环是体会不到的，你对于现代艺术手法没有了解是听不懂的。**

  

**不多说了，点开DISCO，让我再指一会儿脑袋上的灯球。**

** 两个食指就像两个窜天猴  **

**指向闪耀的灯球**

**🎵**

  

  

** 章北海的自然选择  **

有关自由，无关风月

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguBasx7VuZQRiaA0KtSR9ZQNqOJ1MDsibKuzFPM8CoSgVAvMAgibsicsmmicsxib7lIXG5tpWsZbOeoBxicA/640?wx_fmt=jpeg)

长按二维  码扫描关注

微信内阅读原文直接关注  

预览时标签不可点

阅读原文




知道了




****

取消  允许

****

取消  允许

****

取消  允许



__









