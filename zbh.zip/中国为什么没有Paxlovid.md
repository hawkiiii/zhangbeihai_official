#  中国为什么没有Paxlovid？

原创  章北海official  章北海official  章北海的自然选择

_2023年01月10日 18:33_ __ _ _ _ _ _ 河北  _

在小说阅读器读本章

去阅读

![](https://mmbiz.qpic.cn/mmbiz_png/sa8NYIcBEImVial2CVicrEibvRcuHd9dGsR5FbWDvtGF70zrec6YoUEvpbwL126BpAwEd4xbia1WB2mSbfM8YIx6icw/640?wx_fmt=png)

**点击 章北海的自然选择  加关注 **

China

Pha  rmaceutical

Industry

  

**中国制药**

昨天谈了辉瑞的Paxlovid，回复了几条读者留言后，我意识到一个问题： **如果Paxlovid是国产药品，恐怕受到的争议要小得多得多。**
许多人提出的一系列质疑，基本上属于华夷之辨，  只能算立场问题，  在临床数据面前都很无力。

  

我一向主张，医疗的归医疗，政治的归政治，生命比政治立场问题要紧的多。

**  
**

**大批双盲实验都没做过，效用不明，副作用不明，不良反应也不明的“三不明”药品都敢走入千家万户大门，却很少有人提出质疑。**

**  
**

**那么进一步，更核心的问题是，为什么开发出Paxlovid卖到全世界的不是我们？**

![](https://mmbiz.qpic.cn/mmbiz_png/CA6BicApkkgu3aucFmntX5TeKlKaFoWH5iaHsvx1J3akB5AhLlDVKmcViashJkCPECmwevXia4TUpQFbhmF3JfiaJ8g/640?wx_fmt=png)
![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkgu3aucFmntX5TeKlKaFoWH5o6SDL94N4B79YlwvjorJDJIeVPIJ8kX9AQ63ibu9Xnmv0g4f8Edz3Gw/640?wx_fmt=jpeg)

注意，下图为上半年数据

  

随便找一份公开的财报数据，2021年度辉瑞全年研发费用138.29亿美元，占全部收入的约17%。
**开发莫诺拉韦的默沙东投入122亿美元，占比更是达到了约25%。**

**  
**

**现在药物开发，不论小分子药还是大分子药，都需要大量的临床实验，科学计算以及重复的试错和验证，往往是一个药品背后有着众多失败方案和天量投入，**
所以研发投入决定了药企能不能拿出具有独创性的新药品。

**  
**

时代周报推出一个2022年中国化药企业竞争力20强榜单，可以说是中国制药行业的精英企业，但有数据可查的仅有4家研发投入达到两位数，绝大多数药企研发投入在5%以下。

**  
**

**可以遗憾地这么说，在A股的中国上市药企，研发投入能超过10%，都能算是该公司奋发图强，力争上游。**

**  
**

**不怕比别人差，怕的是比别人差还不努力。**

![](https://mmbiz.qpic.cn/mmbiz_png/CA6BicApkkgu3aucFmntX5TeKlKaFoWH5AApemjeSHoqXo92PwSomfyzXFMIsvk26licbUI9dM6OaxcYwL4O0yBw/640?wx_fmt=png)

@时代数据

  

那么， **药企** **收入都去哪了？**

**  
**

**正好这半个月以来以岭药业股价戏剧性暴跌，我们不妨来看一看，在这波疫情当中火遍大江南北，生产连花清瘟的企业是怎么分配它的收入的**

  

以岭药业2021年报总营收101亿，其中销售费用就达到了34亿元之多，而这也并非以岭药业一家的现象：国药控股，华润医药，上海医药等等企业算良心企业仅有个位数的销售费率，这种企业在A股凤毛麟角：

**  
**

**步长制药销售费率46.9%，中国生物37.8%，石药集团34.6%，太极集团34.0%，济川药业47.1%……越是中型药企越是普遍的把三成左右的收入投入到营销当中，想尽办法把自己手里的药品卖出去。除开药品的成本**

  

所谓销售费用，我们应该不陌生，电视上天天都有药品广告，每个医院里面都有到处乱窜的医药代表，每年都能爆出医院和医生大量吃回扣养科室的事情。

  

作为对比， **哪怕是最重视营销，广告打的铺天盖地的酿酒企业** ，销售费率也普遍在10%到20%的水平，
**衡水老白干31%的营销费用已经冠绝中国，而这种比例在制药企业根本排不上号。**

  

**我们应该好好看一看这份榜单，我们吃的药，收入大头不是去研发新的药品，卖到世界市场上赚别人钱，而是变成销售费用，成为各种广告、回扣、滋生各种腐败，把人民群众的病痛当成交易的工具。**

**  
**

**这种环境怎么能开发的出来救命的新药品？**

![](https://mmbiz.qpic.cn/mmbiz_png/CA6BicApkkgu3aucFmntX5TeKlKaFoWH5IbQH1le0fotQ5wznqyibdQHVUapdMcUg2yLMR6oIkvOsDahHwI8aenA/640?wx_fmt=png)
![](https://mmbiz.qpic.cn/mmbiz_png/CA6BicApkkgu3aucFmntX5TeKlKaFoWH50284rOtjiaO6fe5UQFIHINfdVYauzdxnahibJa9P91XyW2OyU4vibKwEQ/640?wx_fmt=png)

还在跌

突出一个深不见底

  

而关于我们的自研药品，最近大出风头，很有希望的阿兹夫定，其背后是河南真实生物，老板是平顶山搞煤炭的王朝阳。

**  
**

**作为煤老板，敢于承担巨大风险，拿出一大笔钱，给郑州大学的团队开发药品，**
而他更有先见性的是，从国外挖了默沙东的团队，组建生产与科研中心，做到产学研结合。

  

小分子生物原研药很难成功，做出阿兹夫定这样的成功药品反而是小概率事件，事实上，阿兹夫定的成功也有一定运气成分，王朝阳最开始想做的是一款治疗艾滋病的药品，结果因为原理相同，在治疗新冠上歪打正着。

  

我一向很少吹中国的资本。但是我确实佩服王朝阳的魄力。 **但更紧要的问题是，中国制药的未来，为什么偏偏掌握在歪打正着的煤老板手里？**

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkgu3aucFmntX5TeKlKaFoWH5RKEvLaJwnqRGJ88KMic7ToiabdqDchVPUmaOb9Xvvf1BEWZCmlmbaoeQ/640?wx_fmt=jpeg)

常俊标

郑州大学化学系教授 阿兹夫定创造者

  

我们已经蒙着眼睛做吃不到葡萄说葡萄酸的狐狸太久了，到了最基本的科学都抛之脑后的地步：

  

我们的药企如果继续沉迷于靠销售费用，靠地下规则，靠灰色收入，靠药品广告，把高利润的药品卖出去，而不搞自主研发。那我们的药品永远只能在自己的国家里打转，
**甚至搞出一大堆这也不明确那也不明确，毒副作用和药物原理都解释不清楚的安慰剂，那才是对医保资金更大，长期的浪费。**

  

**我不是瞧不起煤老板，而是说术业有专攻，我们总不能指望每次都是煤老板来挽救中国制药，而一个需要每次被煤老板挽救制药行业的国家，绝不是我们希望的样子。**

  

** 章北海的自然选择  **

有关自由，无关风月

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkgurZszHFAYnRvdOzVVG0TbwwotITaP6ovVr6Fd8IoBPz1917mhHYLLulsicVqjaXBMfgWAbd2ZNLZw/640?wx_fmt=jpeg)

长按二维  码扫描关注

点击阅读原文直接关注  

预览时标签不可点

阅读原文

阅读




知道了




****

取消  允许

****

取消  允许

****

取消  允许



__









