#  AO3之死，让我看清了饭圈有多恶心

原创  章北海  章北海  章北海的自然选择

_2020年03月01日 19:36_ __ _ _ _ _

在小说阅读器读本章

去阅读

![](https://mmbiz.qpic.cn/mmbiz_png/WLnQS7Jzsbzqqicvz6iaf1H2WzV0UJibba4PnJo554HscTY6gN68YwI1eOgWzPGK9IWNobkv7bN66bkZsib4AKXFsw/640?wx_fmt=png)

**点击 蓝字加  关注 **

  

Archive Of our Own

**武器的批判**

**  
**

考虑到很多人没有听说过AO3被屏蔽，甚至压根都没有听说过AO3这个网站，我就把事情的缘由跟大家说一遍。

  

AO3，是Archive Of Our Own的缩写，这是全世界最大的同人小说数据库。

  

同人，顾名思义，就是人物相同。也是爱好者们喜欢某些人物，从而为这些人物写的小说。

  

**中国有写同人小说的传统，比如《西游记》就是《大唐西域记》的同人小说，同人成了成了名著，成为了民族记忆。**

**  
**

**其实《水浒》也有广为流传的同人小说，只不过比较见不得光，一般不放在桌面上谈。**

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkgsW4n9VRoP0zqTQjDicIW0YH0sJqJsVHH6p8rG2Lla7NM7SVhozO6SUtby9DzdB1W64ibXM46YTicLZg/640?wx_fmt=jpeg)

大唐西域记

玄奘法师取经的见闻

  

同人小说已经是当下文学创作的一种形式，尽管并不严肃，也和传统意义上的高级文学没什么关联，但是同人小说也不在乎这些，它本来就源于对人物的热爱，而产生的一种再创作。

  

知名作者叫太太，喜剧团圆叫发糖，悲剧戏份则叫发刀……这是一个已经产生语言壁垒的小众圈子，AO3就是这个群体交流的平台，无非自娱自乐，其乐融融。

  

**偏偏有人，要上纲上线，诉诸公权。**

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkgsW4n9VRoP0zqTQjDicIW0YHOyDlyZXxGqJBic5Zaz2Vxntj3JbZsKvaA8yhiaPdbFXYG53RKwuap2dQ/640?wx_fmt=jpeg)

一人之下心

千万人之心也

  

事情的起因是网站上有作者写了一篇当红小鲜肉，肖战和王一博的同人小说。肖战粉丝认为侮辱了肖战形象，于是愤而向上举报。

  

**2月29日，AO3被屏蔽，无法正常访问，这座曾经获得雨果奖的互联网档案馆，无数人的心血和文字，随着一群饭圈粉丝的举报付之一炬。**

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkgsW4n9VRoP0zqTQjDicIW0YHDq6dzicByMtQV9MUxh8s9tnDAyORyAdCwuYiawK1ad4BJ1N8UbnkdtnQ/640?wx_fmt=jpeg)

AO3关于网站无法访问的说明

  

马克思说，批判的武器远胜武器的批判。假如你反对一件事情，最佳的做法永远是据理力争，开宗明义，争取支持者，而不是诉诸公权，动辄向权力提起举报。

  

当然，这些举报者肯定没读过马克思，当然也不知道如何科学正确的批判，更别提什么叫批判的武器，他们唯一会的，就是巨婴式的哭闹，试图动用更高级的铁拳。

  

**在巨婴们手里，批判的武器远没有武器的批判来的快速又实际。**

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkgsW4n9VRoP0zqTQjDicIW0YHUxjOqap8vyuuEPp5Gf46iaIeCBuIb1p434g9fJaIk0e4KRiaOL6FXDlQ/640?wx_fmt=jpeg)

粉丝领头人

在社交网站上公开举报方法

  

这两年越来越多的人进入了饭圈，饭圈越来越泛化，明星搞饭圈，宣传口自己也搞饭圈，现在就连火神山的小叉车都要搞饭圈文化打榜。

  

说实在的，挺腌臜的。沉迷于一种低幼叙事而无法自拔，无非是党同伐异。

  

**本质上是弱势个人在强势集体中寻找存在感，破坏、叫嚣、制造冲突，似于初中男生打群架消耗无处发泄的精力，幼稚得很。**

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkgsW4n9VRoP0zqTQjDicIW0YHLcQXH2fcNnJyjfkdCBokaiaIwqJ7LnI09WbHop8dX9v2EjCorDuZURQ/640?wx_fmt=jpeg)

今日割五城

明日割十城

  

饭圈觉得自己不喜欢别人写的文章就可以举报平台，居然还能成功，这实在是很可怕的一件事情。

**  
**

**长此以往，越来越多的圈子将会竖起大旗党同伐异，对不合自己心意的互联网内容对簿公堂。**

**  
**

相互举报的黑暗年代，这个世界也曾经经历过，20世纪，德国侵略波兰的时候，几百万犹太人，很多是从波兰领土上被揪出来的。

  

当时波兰人跟NAZI去告发检举自己的邻居，朋友，同学是犹太人。有些人不擅长批判的武器，只敢躲在权力身下委曲求全。

  

**后来的事情你们也知道了，那是人类的灾难。**

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkgsW4n9VRoP0zqTQjDicIW0YHgec28Y6JLD66jekuzicU7lFibIoUrYOr2tukibKadyNb8IGB2GkdUJiaGA/640?wx_fmt=jpeg)

奥斯维辛

波兰境内最大的犹太人集中营

  

低龄化饭圈所带来的举报，可能是天底下最可怕的事情，盲目的群体认知开始形成，所有的恶被以爱的名义包裹，被合理化，被高高举起成为相互迫害的大旗。

  

不喜欢就毁掉本来就够强盗逻辑，更可惧的，是不喜欢，又没有毁掉的权力，要硬生生借过一只大手来完成破坏的过程，没有辩解，没有回旋的余地。

  

**这些粉丝有没有想过，这种方法有一天会被拿来对付自己？**

  

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkgsW4n9VRoP0zqTQjDicIW0YHnG30KHxZDfkxALGvruo7BNyqSYyQ5iamzjgnniaRTibaicQaZxQTuXk59g/640?wx_fmt=jpeg)

举报者洋洋得意

其他人万马齐喑

  

这个社会有明规则，但更多时候靠潜规则运行，当红小鲜肉们靠同人文炒作热度，制造话题吸引粉丝，掩盖其孱弱的内容产出能力与乏善可陈的演技，这本来就是潜规则，经纪公司和演员本人都从中受益匪浅。

  

**饭圈粉丝们一边靠潜规则维持偶像的热度，一边又靠明规则攻讦见解不同之人，端起碗吃饭，放下碗骂娘，说的就是这一路人。**

![](https://mmbiz.qpic.cn/mmbiz_png/CA6BicApkkgsW4n9VRoP0zqTQjDicIW0YHZNmp7OMUhGTxMdqkwbh1RJgayKOgCuNrIbeRSiaqJHwctfiauumGumEQ/640?wx_fmt=png)

论网络暴力

肖战粉丝真的战斗力不错

  

最好的报复，无非是以毒攻毒，其人之道还治其人之身，向上举报其粉丝网络暴力，言语辱骂，人身攻击，明星明显带动粉丝群体负能量，建议封杀。

  

**说实在的，在一座网络档案馆毁灭后，我最想看的是，当自己的偶像被封杀时，那群饭圈粉丝的脸。**

**  
**

**因为不喜欢，而选择焚书，选择毁灭文化与别人梦想的人，不值得有什么偶像。**

  

** 章北海的自然选择  **

有关自由，无关风月

![](https://mmbiz.qpic.cn/mmbiz_jpg/CA6BicApkkguy2ibpzjSu1P5RkGaVuh94CpxMlkvLkpApzcN4bAgWM8ktUHON9w1hM3qIlAsAST4Zeot4lIjZDMg/640?wx_fmt=jpeg)

长按二维  码扫描关注

点击阅读原文直接关注  

预览时标签不可点

阅读原文

阅读




知道了




****

取消  允许

****

取消  允许

****

取消  允许



__









